package com.example.service;

import com.example.models.ApiDetails;
import com.example.models.ApiRegistryDetail;

import java.util.List;

public interface ApiFilterService {
    public abstract List<ApiDetails> getFilteredListOfApis(final ApiRegistryDetail apiRegistryDetail, final String filterValue);
}
