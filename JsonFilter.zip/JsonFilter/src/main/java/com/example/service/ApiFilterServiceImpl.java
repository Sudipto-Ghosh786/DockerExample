package com.example.service;

import com.example.models.ApiDetails;
import com.example.models.ApiRegistryDetail;

import java.util.List;
import java.util.stream.Collectors;

public class ApiFilterServiceImpl implements ApiFilterService {
    public List<ApiDetails> getFilteredListOfApis(final ApiRegistryDetail apiRegistryDetail, final String type, final String filterValue) {
        return apiRegistryDetail.getApis()
                .stream()
                .filter(apiDetails ->
                        apiDetails.getProperties()
                                .stream()
                                .anyMatch(apiProperties -> apiProperties.getType().equals(type)
                                        && apiProperties.getValue().contains(filterValue))
                )
                .collect(Collectors.toList());
    }
}
