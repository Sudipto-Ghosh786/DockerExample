package com.example.constants;

public class Constants {
    public static final String INPUT_FILE_PATH = "src/main/resources/apis.json";
    public static final String OUTPUT_FILE_PATH = "src/main/resources/filteredApis.json";
}
