package com.example.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiRegistryDetail {
    private String name;
    private String description;
    private String url;
    private Integer offset;
    private Integer totalCount;
    List<ApiDetails> apis;
}
