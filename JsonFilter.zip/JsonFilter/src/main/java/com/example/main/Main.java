package com.example.main;

import com.example.models.ApiRegistryDetail;
import com.example.service.ApiFilterServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;

import static com.example.constants.Constants.INPUT_FILE_PATH;
import static com.example.constants.Constants.OUTPUT_FILE_PATH;

public class Main {
    public static void main(String[] args) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            ApiFilterServiceImpl apiFilterService = new ApiFilterServiceImpl();
            ApiRegistryDetail apiRegistryDetail = objectMapper.readValue(new File(INPUT_FILE_PATH),
                    ApiRegistryDetail.class);
            apiRegistryDetail.setApis(apiFilterService.getFilteredListOfApis(apiRegistryDetail, "2023"));
            objectMapper.writeValue(new File(OUTPUT_FILE_PATH), apiRegistryDetail);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
