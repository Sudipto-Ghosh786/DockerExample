package com.example.main;

import com.example.models.ApiRegistryDetail;
import com.example.service.ApiFilterServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;

import static com.example.constants.Constants.INPUT_FILE_PATH;
import static com.example.constants.Constants.OUTPUT_FILE_PATH;

public class Main {
    public static void main(String[] args) {
        try {
            System.out.println("Input File Path :- " + INPUT_FILE_PATH);
            ObjectMapper objectMapper = new ObjectMapper();
            ApiFilterServiceImpl apiFilterService = new ApiFilterServiceImpl();
            ApiRegistryDetail apiRegistryDetail = objectMapper.readValue(new File(INPUT_FILE_PATH),
                    ApiRegistryDetail.class);
            apiRegistryDetail.setApis(apiFilterService.getFilteredListOfApis(apiRegistryDetail, "X-Created", "2023"));
            objectMapper.writeValue(new File(OUTPUT_FILE_PATH), apiRegistryDetail);
            System.out.println("Updated File Path :- " + OUTPUT_FILE_PATH);
            System.out.println("PROGRAM COMPLETED SUCCESSFULLY");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
